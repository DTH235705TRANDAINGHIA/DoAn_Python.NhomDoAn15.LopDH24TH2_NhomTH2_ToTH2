# main.py
# Ứng dụng Tkinter: Quản lý Sinh viên - Phòng - Hợp đồng
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from models import (
    lay_tat_ca_sinh_vien, them_sinh_vien, cap_nhat_sinh_vien, xoa_sinh_vien,
    lay_tat_ca_phong, them_phong, cap_nhat_phong, xoa_phong,
    lay_tat_ca_hop_dong, them_hop_dong, cap_nhat_hop_dong, xoa_hop_dong
)
import csv
from datetime import datetime
import threading

class UngDung(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Quản lý Ký túc xá")
        self.geometry("1000x650")
        self.khoi_tao_giao_dien()

    def khoi_tao_giao_dien(self):
        nb = ttk.Notebook(self)
        nb.pack(fill='both', expand=True)

        self.tab_sv = ttk.Frame(nb); nb.add(self.tab_sv, text="Sinh viên")
        self.tab_phong = ttk.Frame(nb); nb.add(self.tab_phong, text="Phòng")
        self.tab_hd = ttk.Frame(nb); nb.add(self.tab_hd, text="Hợp đồng")

        self.xay_dung_tab_sinh_vien()
        self.xay_dung_tab_phong()
        self.xay_dung_tab_hop_dong()

    # ---------- Tab Sinh viên ----------
    def xay_dung_tab_sinh_vien(self):
        f = self.tab_sv
        top = ttk.Frame(f); top.pack(fill='x', padx=6, pady=6)
        ttk.Label(top, text="Tìm (mã/tên):").pack(side='left')
        self.tk_sv_search = tk.StringVar()
        ttk.Entry(top, textvariable=self.tk_sv_search).pack(side='left', padx=6)
        ttk.Button(top, text="Tìm", command=self.tim_sinh_vien).pack(side='left')
        ttk.Button(top, text="Làm mới", command=self.load_sinh_vien).pack(side='left', padx=6)
        ttk.Button(top, text="Thêm sinh viên", command=self.them_sinh_vien_ui).pack(side='right', padx=4)
        ttk.Button(top, text="Xuất CSV", command=lambda: self.xuat_csv(self.tree_sv, "sinh_vien")).pack(side='right')

        cols = ("student_id","student_code","full_name","phone","email","dob","gender","address")
        self.tree_sv = ttk.Treeview(f, columns=cols, show='headings')
        for c in cols:
            self.tree_sv.heading(c, text=c.replace("_"," ").title())
            self.tree_sv.column(c, anchor='center')
        self.tree_sv.pack(fill='both', expand=True, padx=6, pady=6)
        self.tree_sv.bind("<Double-1>", self.sua_sinh_vien_ui)

        btnf = ttk.Frame(f); btnf.pack(fill='x', padx=6, pady=6)
        ttk.Button(btnf, text="Sửa", command=self.sua_sinh_vien_ui).pack(side='left')
        ttk.Button(btnf, text="Xóa", command=self.xoa_sinh_vien_ui).pack(side='left', padx=6)

        self.load_sinh_vien()

    def load_sinh_vien(self):
        def task():
            try:
                rows = lay_tat_ca_sinh_vien() or []
                self.tree_sv.delete(*self.tree_sv.get_children())
                for r in rows:
                    self.tree_sv.insert('', 'end', values=(
                        r['student_id'], r['student_code'], r['full_name'],
                        r.get('phone') or '', r.get('email') or '',
                        r.get('dob').strftime('%Y-%m-%d') if r.get('dob') else '',
                        r.get('gender') or '', r.get('address') or ''
                    ))
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi khi tải sinh viên: {e}")
        threading.Thread(target=task, daemon=True).start()

    def tim_sinh_vien(self):
        term = self.tk_sv_search.get().strip().lower()
        if not term:
            self.load_sinh_vien(); return
        for iid in self.tree_sv.get_children():
            vals = self.tree_sv.item(iid)['values']
            if term in str(vals[1]).lower() or term in str(vals[2]).lower():
                self.tree_sv.reattach(iid, '', 'end')
            else:
                self.tree_sv.detach(iid)

    def them_sinh_vien_ui(self):
        FormSinhVien(self, on_save=lambda data: (them_sinh_vien(**data), self.load_sinh_vien()))

    def sua_sinh_vien_ui(self, event=None):
        sel = self.tree_sv.selection()
        if not sel:
            messagebox.showwarning("Chú ý", "Chọn sinh viên để sửa"); return
        item = self.tree_sv.item(sel[0])['values']
        ini = {'student_id': item[0], 'student_code': item[1], 'full_name': item[2], 'phone': item[3], 'email': item[4], 'dob': item[5], 'gender': item[6], 'address': item[7]}
        FormSinhVien(self, initial=ini, on_save=lambda data: (cap_nhat_sinh_vien(data['student_id'], data['full_name'], data['phone'], data['email'], data['dob'] or None, data['gender'], data['address']), self.load_sinh_vien()))

    def xoa_sinh_vien_ui(self):
        sel = self.tree_sv.selection()
        if not sel:
            messagebox.showwarning("Chú ý", "Chọn sinh viên để xóa"); return
        if not messagebox.askyesno("Xác nhận", "Bạn có chắc muốn xóa?"): return
        item = self.tree_sv.item(sel[0])['values']
        try:
            xoa_sinh_vien(item[0])
            self.load_sinh_vien()
        except Exception as e:
            messagebox.showerror("Lỗi", str(e))

    # ---------- Tab Phòng ----------
    def xay_dung_tab_phong(self):
        f = self.tab_phong
        top = ttk.Frame(f); top.pack(fill='x', padx=6, pady=6)
        ttk.Button(top, text="Thêm phòng", command=self.them_phong_ui).pack(side='right', padx=4)
        ttk.Button(top, text="Xuất CSV", command=lambda: self.xuat_csv(self.tree_phong, "phong")).pack(side='right')

        cols = ("room_id","room_number","capacity","price_per_month","note")
        self.tree_phong = ttk.Treeview(f, columns=cols, show='headings')
        for c in cols:
            self.tree_phong.heading(c, text=c.replace("_"," ").title())
            self.tree_phong.column(c, anchor='center')
        self.tree_phong.pack(fill='both', expand=True, padx=6, pady=6)
        self.tree_phong.bind("<Double-1>", self.sua_phong_ui)

        btnf = ttk.Frame(f); btnf.pack(fill='x', padx=6, pady=6)
        ttk.Button(btnf, text="Sửa", command=self.sua_phong_ui).pack(side='left')
        ttk.Button(btnf, text="Xóa", command=self.xoa_phong_ui).pack(side='left', padx=6)

        self.load_phong()

    def load_phong(self):
        def task():
            try:
                rows = lay_tat_ca_phong() or []
                self.tree_phong.delete(*self.tree_phong.get_children())
                for r in rows:
                    self.tree_phong.insert('', 'end', values=(r['room_id'], r['room_number'], r['capacity'], float(r['price_per_month']), r.get('note') or ''))
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi khi tải phòng: {e}")
        threading.Thread(target=task, daemon=True).start()

    def them_phong_ui(self):
        FormPhong(self, on_save=lambda data: (them_phong(**data), self.load_phong()))

    def sua_phong_ui(self, event=None):
        sel = self.tree_phong.selection()
        if not sel:
            messagebox.showwarning("Chú ý", "Chọn phòng để sửa"); return
        item = self.tree_phong.item(sel[0])['values']
        ini = {'room_id': item[0], 'room_number': item[1], 'capacity': item[2], 'price_per_month': item[3], 'note': item[4]}
        FormPhong(self, initial=ini, on_save=lambda data: (cap_nhat_phong(data['room_id'], data['capacity'], data['price_per_month'], data['note']), self.load_phong()))

    def xoa_phong_ui(self):
        sel = self.tree_phong.selection()
        if not sel:
            messagebox.showwarning("Chú ý", "Chọn phòng để xóa"); return
        if not messagebox.askyesno("Xác nhận", "Bạn có chắc muốn xóa?"): return
        item = self.tree_phong.item(sel[0])['values']
        try:
            xoa_phong(item[0])
            self.load_phong()
        except Exception as e:
            messagebox.showerror("Lỗi", str(e))

    # ---------- Tab Hợp đồng ----------
    def xay_dung_tab_hop_dong(self):
        f = self.tab_hd
        top = ttk.Frame(f); top.pack(fill='x', padx=6, pady=6)
        ttk.Button(top, text="Thêm hợp đồng", command=self.them_hop_dong_ui).pack(side='right', padx=4)
        ttk.Button(top, text="Xuất CSV", command=lambda: self.xuat_csv(self.tree_hd, "hop_dong")).pack(side='right')

        cols = ("contract_id","student_code","full_name","room_number","start_date","end_date","monthly_fee","status")
        self.tree_hd = ttk.Treeview(f, columns=cols, show='headings')
        for c in cols:
            self.tree_hd.heading(c, text=c.replace("_"," ").title())
            self.tree_hd.column(c, anchor='center')
        self.tree_hd.pack(fill='both', expand=True, padx=6, pady=6)
        self.tree_hd.bind("<Double-1>", self.sua_hop_dong_ui)

        btnf = ttk.Frame(f); btnf.pack(fill='x', padx=6, pady=6)
        ttk.Button(btnf, text="Sửa", command=self.sua_hop_dong_ui).pack(side='left')
        ttk.Button(btnf, text="Xóa", command=self.xoa_hop_dong_ui).pack(side='left', padx=6)

        self.load_hop_dong()

    def load_hop_dong(self):
        def task():
            try:
                rows = lay_tat_ca_hop_dong() or []
                self.tree_hd.delete(*self.tree_hd.get_children())
                for r in rows:
                    self.tree_hd.insert('', 'end', values=(
                        r['contract_id'], r['student_code'], r['full_name'], r['room_number'],
                        r.get('start_date').strftime('%Y-%m-%d') if r.get('start_date') else '',
                        r.get('end_date').strftime('%Y-%m-%d') if r.get('end_date') else '',
                        float(r['monthly_fee']) if r.get('monthly_fee') else '',
                        r.get('status') or ''
                    ))
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi khi tải hợp đồng: {e}")
        threading.Thread(target=task, daemon=True).start()

    def them_hop_dong_ui(self):
        FormHopDong(self, on_save=lambda data: (them_hop_dong(**data), self.load_hop_dong()))

    def sua_hop_dong_ui(self, event=None):
        sel = self.tree_hd.selection()
        if not sel:
            messagebox.showwarning("Chú ý", "Chọn hợp đồng để sửa"); return
        item = self.tree_hd.item(sel[0])['values']
        ini = {'contract_id': item[0], 'student_code': item[1], 'full_name': item[2], 'room_number': item[3], 'start_date': item[4], 'end_date': item[5], 'monthly_fee': item[6], 'status': item[7]}
        FormHopDong(self, initial=ini, on_save=lambda data: (cap_nhat_hop_dong(data['contract_id'], data['end_date'] or None, data['monthly_fee'] or None, data['status']), self.load_hop_dong()))

    def xoa_hop_dong_ui(self):
        sel = self.tree_hd.selection()
        if not sel:
            messagebox.showwarning("Chú ý", "Chọn hợp đồng để xóa"); return
        if not messagebox.askyesno("Xác nhận", "Bạn có chắc muốn xóa?"): return
        item = self.tree_hd.item(sel[0])['values']
        try:
            xoa_hop_dong(item[0])
            self.load_hop_dong()
        except Exception as e:
            messagebox.showerror("Lỗi", str(e))

    # ---------- Utility ----------
    def xuat_csv(self, tree, prefix):
        rows = [tree.item(i)['values'] for i in tree.get_children()]
        if not rows:
            messagebox.showinfo("Thông báo", "Không có dữ liệu để xuất"); return
        fname = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=f"{prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv")
        if not fname: return
        with open(fname, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            cols = [tree.heading(c)['text'] for c in tree['columns']]
            writer.writerow(cols)
            writer.writerows(rows)
        messagebox.showinfo("OK", f"Đã lưu file: {fname}")

# ---------------- Các lớp Form (Sinh viên / Phòng / Hợp đồng) ----------------
class FormSinhVien(tk.Toplevel):
    def __init__(self, parent, initial=None, on_save=None):
        super().__init__(parent)
        self.on_save = on_save
        self.initial = initial or {}
        self.title("Form Sinh viên")
        self.geometry("420x360")
        self.xay_dung()

    def xay_dung(self):
        frm = ttk.Frame(self); frm.pack(padx=8, pady=8, fill='both', expand=True)
        labels = [("Mã SV","student_code"),("Họ tên","full_name"),("SĐT","phone"),("Email","email"),("Ngày sinh (YYYY-MM-DD)","dob"),("Giới tính","gender"),("Địa chỉ","address")]
        self.vars = {}
        for i,(lab,key) in enumerate(labels):
            ttk.Label(frm, text=lab).grid(row=i, column=0, sticky='w', pady=4)
            v = tk.StringVar(value=self.initial.get(key,""))
            ttk.Entry(frm, textvariable=v).grid(row=i, column=1, sticky='ew', padx=6)
            self.vars[key] = v
        frm.columnconfigure(1, weight=1)
        bf = ttk.Frame(frm); bf.grid(row=len(labels), column=0, columnspan=2, pady=8)
        ttk.Button(bf, text="Lưu", command=self.luu).pack(side='left', padx=6)
        ttk.Button(bf, text="Hủy", command=self.destroy).pack(side='left')

    def luu(self):
        data = {k:v.get().strip() for k,v in self.vars.items()}
        if not data['student_code'] or not data['full_name']:
            messagebox.showwarning("Thiếu", "Mã và họ tên không được để trống"); return
        if self.initial.get('student_id'):
            data['student_id'] = self.initial['student_id']
        try:
            if self.on_save:
                self.on_save(data)
            self.destroy()
        except Exception as e:
            messagebox.showerror("Lỗi khi lưu", str(e))

class FormPhong(tk.Toplevel):
    def __init__(self, parent, initial=None, on_save=None):
        super().__init__(parent)
        self.on_save=on_save; self.initial=initial or {}
        self.title("Form Phòng"); self.geometry("360x220"); self.xay_dung()

    def xay_dung(self):
        frm=ttk.Frame(self); frm.pack(padx=8,pady=8,fill='both',expand=True)
        labels=[("Số phòng","room_number"),("Sức chứa","capacity"),("Giá/tháng","price_per_month"),("Ghi chú","note")]
        self.vars={}
        for i,(lab,key) in enumerate(labels):
            ttk.Label(frm,text=lab).grid(row=i,column=0,sticky='w',pady=4)
            v=tk.StringVar(value=str(self.initial.get(key,"")))
            ttk.Entry(frm,textvariable=v).grid(row=i,column=1,sticky='ew',padx=6)
            self.vars[key]=v
        frm.columnconfigure(1,weight=1)
        bf=ttk.Frame(frm); bf.grid(row=len(labels),column=0,columnspan=2,pady=8)
        ttk.Button(bf,text="Lưu",command=self.luu).pack(side='left',padx=6)
        ttk.Button(bf,text="Hủy",command=self.destroy).pack(side='left')

    def luu(self):
        data={k: v.get().strip() for k,v in self.vars.items()}
        if not data['room_number'] or not data['capacity']:
            messagebox.showwarning("Thiếu", "Số phòng và sức chứa không được để trống"); return
        try:
            data['capacity'] = int(data['capacity'])
            data['price_per_month'] = float(data['price_per_month']) if data['price_per_month'] else 0.0
        except:
            messagebox.showwarning("Sai định dạng", "Sức chứa phải là số; giá phải là số"); return
        if self.initial.get('room_id'):
            data['room_id'] = self.initial['room_id']
        try:
            if self.on_save:
                self.on_save(data)
            self.destroy()
        except Exception as e:
            messagebox.showerror("Lỗi khi lưu", str(e))

class FormHopDong(tk.Toplevel):
    def __init__(self, parent, initial=None, on_save=None):
        super().__init__(parent)
        self.on_save=on_save; self.initial=initial or {}
        self.title("Form Hợp đồng"); self.geometry("420x320"); self.xay_dung()

    def xay_dung(self):
        frm=ttk.Frame(self); frm.pack(padx=8,pady=8,fill='both',expand=True)
        # load danh sách sinh viên + phòng cho combobox
        sv = [(r['student_id'], f"{r['student_code']} - {r['full_name']}") for r in lay_tat_ca_sinh_vien() or []]
        rooms = [(r['room_id'], r['room_number']) for r in lay_tat_ca_phong() or []]

        ttk.Label(frm, text="Sinh viên").grid(row=0,column=0,sticky='w', pady=4)
        self.cb_sv = ttk.Combobox(frm, values=[s[1] for s in sv])
        self.cb_sv.grid(row=0,column=1,sticky='ew',padx=6)

        ttk.Label(frm, text="Phòng").grid(row=1,column=0,sticky='w', pady=4)
        self.cb_room = ttk.Combobox(frm, values=[r[1] for r in rooms])
        self.cb_room.grid(row=1,column=1,sticky='ew',padx=6)

        ttk.Label(frm, text="Ngày bắt đầu (YYYY-MM-DD)").grid(row=2,column=0,sticky='w', pady=4)
        self.start_var = tk.StringVar(value=self.initial.get('start_date',''))
        ttk.Entry(frm, textvariable=self.start_var).grid(row=2,column=1,sticky='ew',padx=6)

        ttk.Label(frm, text="Ngày kết thúc (YYYY-MM-DD)").grid(row=3,column=0,sticky='w', pady=4)
        self.end_var = tk.StringVar(value=self.initial.get('end_date',''))
        ttk.Entry(frm, textvariable=self.end_var).grid(row=3,column=1,sticky='ew',padx=6)

        ttk.Label(frm, text="Giá tháng").grid(row=4,column=0,sticky='w', pady=4)
        self.price_var = tk.StringVar(value=str(self.initial.get('monthly_fee','')))
        ttk.Entry(frm, textvariable=self.price_var).grid(row=4,column=1,sticky='ew',padx=6)

        ttk.Label(frm, text="Trạng thái").grid(row=5,column=0,sticky='w', pady=4)
        self.status_var = tk.StringVar(value=self.initial.get('status','Active'))
        ttk.Entry(frm, textvariable=self.status_var).grid(row=5,column=1,sticky='ew',padx=6)

        frm.columnconfigure(1, weight=1)
        bf = ttk.Frame(frm); bf.grid(row=6, column=0, columnspan=2, pady=8)
        ttk.Button(bf, text="Lưu", command=lambda: self.luu(sv, rooms)).pack(side='left', padx=6)
        ttk.Button(bf, text="Hủy", command=self.destroy).pack(side='left')

    def luu(self, sv, rooms):
        s_text = self.cb_sv.get()
        r_text = self.cb_room.get()
        sid = next((s[0] for s in sv if s[1]==s_text), None)
        rid = next((r[0] for r in rooms if r[1]==r_text), None)
        if not sid or not rid:
            messagebox.showwarning("Thiếu", "Chọn sinh viên và phòng"); return
        start = self.start_var.get().strip()
        end = self.end_var.get().strip() or None
        price = float(self.price_var.get()) if self.price_var.get().strip() else None
        data = {'student_id': sid, 'room_id': rid, 'start_date': start, 'end_date': end, 'monthly_fee': price, 'status': self.status_var.get().strip() or 'Active'}
        if self.initial.get('contract_id'):
            data['contract_id'] = self.initial['contract_id']
        try:
            if self.on_save:
                self.on_save(data)
            self.destroy()
        except Exception as e:
            messagebox.showerror("Lỗi khi lưu", str(e))

if __name__ == "__main__":
    app = UngDung()
    app.mainloop()
