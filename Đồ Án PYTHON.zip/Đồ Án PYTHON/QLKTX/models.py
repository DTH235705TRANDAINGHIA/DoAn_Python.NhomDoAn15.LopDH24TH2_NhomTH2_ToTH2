# models.py
# Các hàm CRUD cho students, rooms, contracts
from db import thuc_thi_cau_lenh

# ===== Students (Sinh viên) =====
def lay_tat_ca_sinh_vien():
    q = "SELECT * FROM students ORDER BY student_id DESC"
    return thuc_thi_cau_lenh(q, fetch=True)

def them_sinh_vien(student_code, full_name, phone=None, email=None, dob=None, gender='Khác', address=None):
    q = """INSERT INTO students (student_code, full_name, phone, email, dob, gender, address)
           VALUES (%s,%s,%s,%s,%s,%s,%s)"""
    thuc_thi_cau_lenh(q, (student_code, full_name, phone, email, dob, gender, address))

def cap_nhat_sinh_vien(student_id, full_name, phone=None, email=None, dob=None, gender='Khác', address=None):
    q = """UPDATE students SET full_name=%s, phone=%s, email=%s, dob=%s, gender=%s, address=%s
           WHERE student_id=%s"""
    thuc_thi_cau_lenh(q, (full_name, phone, email, dob, gender, address, student_id))

def xoa_sinh_vien(student_id):
    q = "DELETE FROM students WHERE student_id=%s"
    thuc_thi_cau_lenh(q, (student_id,))

# ===== Rooms (Phòng) =====
def lay_tat_ca_phong():
    q = "SELECT * FROM rooms ORDER BY room_id DESC"
    return thuc_thi_cau_lenh(q, fetch=True)

def them_phong(room_number, capacity=1, price_per_month=0.0, note=None):
    q = "INSERT INTO rooms (room_number, capacity, price_per_month, note) VALUES (%s,%s,%s,%s)"
    thuc_thi_cau_lenh(q, (room_number, capacity, price_per_month, note))

def cap_nhat_phong(room_id, capacity, price_per_month, note=None):
    q = "UPDATE rooms SET capacity=%s, price_per_month=%s, note=%s WHERE room_id=%s"
    thuc_thi_cau_lenh(q, (capacity, price_per_month, note, room_id))

def xoa_phong(room_id):
    q = "DELETE FROM rooms WHERE room_id=%s"
    thuc_thi_cau_lenh(q, (room_id,))

# ===== Contracts (Hợp đồng) =====
def lay_tat_ca_hop_dong():
    q = """SELECT c.*, s.student_code, s.full_name, r.room_number
           FROM contracts c
           JOIN students s ON c.student_id = s.student_id
           JOIN rooms r ON c.room_id = r.room_id
           ORDER BY c.contract_id DESC"""
    return thuc_thi_cau_lenh(q, fetch=True)

def them_hop_dong(student_id, room_id, start_date, end_date=None, monthly_fee=None, status='Active'):
    q = """INSERT INTO contracts (student_id, room_id, start_date, end_date, monthly_fee, status)
           VALUES (%s,%s,%s,%s,%s,%s)"""
    thuc_thi_cau_lenh(q, (student_id, room_id, start_date, end_date, monthly_fee, status))

def cap_nhat_hop_dong(contract_id, end_date=None, monthly_fee=None, status=None):
    q = "UPDATE contracts SET end_date=%s, monthly_fee=%s, status=%s WHERE contract_id=%s"
    thuc_thi_cau_lenh(q, (end_date, monthly_fee, status, contract_id))

def xoa_hop_dong(contract_id):
    q = "DELETE FROM contracts WHERE contract_id=%s"
    thuc_thi_cau_lenh(q, (contract_id,))
