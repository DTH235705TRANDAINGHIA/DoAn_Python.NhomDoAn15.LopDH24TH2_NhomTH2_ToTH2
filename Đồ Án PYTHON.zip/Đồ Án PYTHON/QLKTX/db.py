# db.py
# Quản lý kết nối đến MySQL
import os
import mysql.connector
from mysql.connector import Error

# Cấu hình: ưu tiên lấy từ biến môi trường; nếu muốn test nhanh, chỉnh trực tiếp ở đây
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_USER = os.getenv("DB_USER", "root")
DB_PASS = os.getenv("DB_PASS", "")
DB_NAME = os.getenv("DB_NAME", "dorm_management")
DB_PORT = int(os.getenv("DB_PORT", 3306))

def lay_ket_noi():
    """Trả về object kết nối (mysql.connector.connect)."""
    try:
        conn = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASS,
            database=DB_NAME,
            port=DB_PORT,
            autocommit=False
        )
        return conn
    except Error as e:
        raise Exception(f"Lỗi kết nối CSDL: {e}")

def thuc_thi_cau_lenh(query, params=None, fetch=False):
    """
    Thực thi câu lệnh SQL.
    Nếu fetch=True -> trả về danh sách kết quả.
    """
    conn = lay_ket_noi()
    cur = conn.cursor(dictionary=True)
    try:
        cur.execute(query, params or ())
        if fetch:
            rows = cur.fetchall()
        else:
            rows = None
        conn.commit()
        return rows
    except Exception as e:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()

